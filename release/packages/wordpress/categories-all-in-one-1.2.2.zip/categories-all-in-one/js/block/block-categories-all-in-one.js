(() => {
  function tn(o, n) {
    (n == null || n > o.length) && (n = o.length);
    for (var s = 0, u = Array(n); s < n; s++) u[s] = o[s];
    return u;
  }
  function so(o) {
    if (Array.isArray(o)) return o;
  }
  function co(o, n) {
    var s = o == null ? null : (typeof Symbol < 'u' && o[Symbol.iterator]) || o['@@iterator'];
    if (s != null) {
      var u,
        m,
        g,
        D,
        ae = [],
        v = !0,
        le = !1;
      try {
        if (((g = (s = s.call(o)).next), n !== 0))
          for (; !(v = (u = g.call(s)).done) && (ae.push(u.value), ae.length !== n); v = !0);
      } catch (Ce) {
        ((le = !0), (m = Ce));
      } finally {
        try {
          if (!v && s.return != null && ((D = s.return()), Object(D) !== D)) return;
        } finally {
          if (le) throw m;
        }
      }
      return ae;
    }
  }
  function uo() {
    throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  function fo(o, n) {
    return so(o) || co(o, n) || po(o, n) || uo();
  }
  function po(o, n) {
    if (o) {
      if (typeof o == 'string') return tn(o, n);
      var s = {}.toString.call(o).slice(8, -1);
      return (
        s === 'Object' && o.constructor && (s = o.constructor.name),
        s === 'Map' || s === 'Set'
          ? Array.from(o)
          : s === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(s)
            ? tn(o, n)
            : void 0
      );
    }
  }
  var Tn = Object.entries,
    nn = Object.setPrototypeOf,
    mo = Object.isFrozen,
    go = Object.getPrototypeOf,
    ho = Object.getOwnPropertyDescriptor,
    N = Object.freeze,
    P = Object.seal,
    Se = Object.create,
    _n = typeof Reflect < 'u' && Reflect,
    Pt = _n.apply,
    Mt = _n.construct;
  N ||
    (N = function (n) {
      return n;
    });
  P ||
    (P = function (n) {
      return n;
    });
  Pt ||
    (Pt = function (n, s) {
      for (var u = arguments.length, m = new Array(u > 2 ? u - 2 : 0), g = 2; g < u; g++)
        m[g - 2] = arguments[g];
      return n.apply(s, m);
    });
  Mt ||
    (Mt = function (n) {
      for (var s = arguments.length, u = new Array(s > 1 ? s - 1 : 0), m = 1; m < s; m++)
        u[m - 1] = arguments[m];
      return new n(...u);
    });
  var Ae = O(Array.prototype.forEach),
    To = O(Array.prototype.lastIndexOf),
    on = O(Array.prototype.pop),
    Ee = O(Array.prototype.push),
    _o = O(Array.prototype.splice),
    oe = Array.isArray,
    Re = O(String.prototype.toLowerCase),
    It = O(String.prototype.toString),
    rn = O(String.prototype.match),
    ve = O(String.prototype.replace),
    an = O(String.prototype.indexOf),
    yo = O(String.prototype.trim),
    bo = O(Number.prototype.toString),
    Ao = O(Boolean.prototype.toString),
    ln = typeof BigInt > 'u' ? null : O(BigInt.prototype.toString),
    sn = typeof Symbol > 'u' ? null : O(Symbol.prototype.toString),
    w = O(Object.prototype.hasOwnProperty),
    ke = O(Object.prototype.toString),
    L = O(RegExp.prototype.test),
    pe = Eo(TypeError);
  function O(o) {
    return function (n) {
      n instanceof RegExp && (n.lastIndex = 0);
      for (var s = arguments.length, u = new Array(s > 1 ? s - 1 : 0), m = 1; m < s; m++)
        u[m - 1] = arguments[m];
      return Pt(o, n, u);
    };
  }
  function Eo(o) {
    return function () {
      for (var n = arguments.length, s = new Array(n), u = 0; u < n; u++) s[u] = arguments[u];
      return Mt(o, s);
    };
  }
  function h(o, n) {
    let s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : Re;
    if ((nn && nn(o, null), !oe(n))) return o;
    let u = n.length;
    for (; u--;) {
      let m = n[u];
      if (typeof m == 'string') {
        let g = s(m);
        g !== m && (mo(n) || (n[u] = g), (m = g));
      }
      o[m] = !0;
    }
    return o;
  }
  function So(o) {
    for (let n = 0; n < o.length; n++) w(o, n) || (o[n] = null);
    return o;
  }
  function R(o) {
    let n = Se(null);
    for (let u of Tn(o)) {
      var s = fo(u, 2);
      let m = s[0],
        g = s[1];
      w(o, m) &&
        (oe(g)
          ? (n[m] = So(g))
          : g && typeof g == 'object' && g.constructor === Object
            ? (n[m] = R(g))
            : (n[m] = g));
    }
    return n;
  }
  function Co(o) {
    switch (typeof o) {
      case 'string':
        return o;
      case 'number':
        return bo(o);
      case 'boolean':
        return Ao(o);
      case 'bigint':
        return ln ? ln(o) : '0';
      case 'symbol':
        return sn ? sn(o) : 'Symbol()';
      case 'undefined':
        return ke(o);
      case 'function':
      case 'object': {
        if (o === null) return ke(o);
        let n = o,
          s = V(n, 'toString');
        if (typeof s == 'function') {
          let u = s(n);
          return typeof u == 'string' ? u : ke(u);
        }
        return ke(o);
      }
      default:
        return ke(o);
    }
  }
  function V(o, n) {
    for (; o !== null;) {
      let u = ho(o, n);
      if (u) {
        if (u.get) return O(u.get);
        if (typeof u.value == 'function') return O(u.value);
      }
      o = go(o);
    }
    function s() {
      return null;
    }
    return s;
  }
  function Oo(o) {
    try {
      return (L(o, ''), !0);
    } catch {
      return !1;
    }
  }
  var cn = N([
      'a',
      'abbr',
      'acronym',
      'address',
      'area',
      'article',
      'aside',
      'audio',
      'b',
      'bdi',
      'bdo',
      'big',
      'blink',
      'blockquote',
      'body',
      'br',
      'button',
      'canvas',
      'caption',
      'center',
      'cite',
      'code',
      'col',
      'colgroup',
      'content',
      'data',
      'datalist',
      'dd',
      'decorator',
      'del',
      'details',
      'dfn',
      'dialog',
      'dir',
      'div',
      'dl',
      'dt',
      'element',
      'em',
      'fieldset',
      'figcaption',
      'figure',
      'font',
      'footer',
      'form',
      'h1',
      'h2',
      'h3',
      'h4',
      'h5',
      'h6',
      'head',
      'header',
      'hgroup',
      'hr',
      'html',
      'i',
      'img',
      'input',
      'ins',
      'kbd',
      'label',
      'legend',
      'li',
      'main',
      'map',
      'mark',
      'marquee',
      'menu',
      'menuitem',
      'meter',
      'nav',
      'nobr',
      'ol',
      'optgroup',
      'option',
      'output',
      'p',
      'picture',
      'pre',
      'progress',
      'q',
      'rp',
      'rt',
      'ruby',
      's',
      'samp',
      'search',
      'section',
      'select',
      'shadow',
      'slot',
      'small',
      'source',
      'spacer',
      'span',
      'strike',
      'strong',
      'style',
      'sub',
      'summary',
      'sup',
      'table',
      'tbody',
      'td',
      'template',
      'textarea',
      'tfoot',
      'th',
      'thead',
      'time',
      'tr',
      'track',
      'tt',
      'u',
      'ul',
      'var',
      'video',
      'wbr',
    ]),
    Dt = N([
      'svg',
      'a',
      'altglyph',
      'altglyphdef',
      'altglyphitem',
      'animatecolor',
      'animatemotion',
      'animatetransform',
      'circle',
      'clippath',
      'defs',
      'desc',
      'ellipse',
      'enterkeyhint',
      'exportparts',
      'filter',
      'font',
      'g',
      'glyph',
      'glyphref',
      'hkern',
      'image',
      'inputmode',
      'line',
      'lineargradient',
      'marker',
      'mask',
      'metadata',
      'mpath',
      'part',
      'path',
      'pattern',
      'polygon',
      'polyline',
      'radialgradient',
      'rect',
      'stop',
      'style',
      'switch',
      'symbol',
      'text',
      'textpath',
      'title',
      'tref',
      'tspan',
      'view',
      'vkern',
    ]),
    Lt = N([
      'feBlend',
      'feColorMatrix',
      'feComponentTransfer',
      'feComposite',
      'feConvolveMatrix',
      'feDiffuseLighting',
      'feDisplacementMap',
      'feDistantLight',
      'feDropShadow',
      'feFlood',
      'feFuncA',
      'feFuncB',
      'feFuncG',
      'feFuncR',
      'feGaussianBlur',
      'feImage',
      'feMerge',
      'feMergeNode',
      'feMorphology',
      'feOffset',
      'fePointLight',
      'feSpecularLighting',
      'feSpotLight',
      'feTile',
      'feTurbulence',
    ]),
    Io = N([
      'animate',
      'color-profile',
      'cursor',
      'discard',
      'font-face',
      'font-face-format',
      'font-face-name',
      'font-face-src',
      'font-face-uri',
      'foreignobject',
      'hatch',
      'hatchpath',
      'mesh',
      'meshgradient',
      'meshpatch',
      'meshrow',
      'missing-glyph',
      'script',
      'set',
      'solidcolor',
      'unknown',
      'use',
    ]),
    wt = N([
      'math',
      'menclose',
      'merror',
      'mfenced',
      'mfrac',
      'mglyph',
      'mi',
      'mlabeledtr',
      'mmultiscripts',
      'mn',
      'mo',
      'mover',
      'mpadded',
      'mphantom',
      'mroot',
      'mrow',
      'ms',
      'mspace',
      'msqrt',
      'mstyle',
      'msub',
      'msup',
      'msubsup',
      'mtable',
      'mtd',
      'mtext',
      'mtr',
      'munder',
      'munderover',
      'mprescripts',
    ]),
    Do = N([
      'maction',
      'maligngroup',
      'malignmark',
      'mlongdiv',
      'mscarries',
      'mscarry',
      'msgroup',
      'mstack',
      'msline',
      'msrow',
      'semantics',
      'annotation',
      'annotation-xml',
      'mprescripts',
      'none',
    ]),
    un = N(['#text']),
    fn = N([
      'accept',
      'action',
      'align',
      'alt',
      'autocapitalize',
      'autocomplete',
      'autopictureinpicture',
      'autoplay',
      'background',
      'bgcolor',
      'border',
      'capture',
      'cellpadding',
      'cellspacing',
      'checked',
      'cite',
      'class',
      'clear',
      'color',
      'cols',
      'colspan',
      'command',
      'commandfor',
      'controls',
      'controlslist',
      'coords',
      'crossorigin',
      'datetime',
      'decoding',
      'default',
      'dir',
      'disabled',
      'disablepictureinpicture',
      'disableremoteplayback',
      'download',
      'draggable',
      'enctype',
      'enterkeyhint',
      'exportparts',
      'face',
      'for',
      'headers',
      'height',
      'hidden',
      'high',
      'href',
      'hreflang',
      'id',
      'inert',
      'inputmode',
      'integrity',
      'ismap',
      'kind',
      'label',
      'lang',
      'list',
      'loading',
      'loop',
      'low',
      'max',
      'maxlength',
      'media',
      'method',
      'min',
      'minlength',
      'multiple',
      'muted',
      'name',
      'nonce',
      'noshade',
      'novalidate',
      'nowrap',
      'open',
      'optimum',
      'part',
      'pattern',
      'placeholder',
      'playsinline',
      'popover',
      'popovertarget',
      'popovertargetaction',
      'poster',
      'preload',
      'pubdate',
      'radiogroup',
      'readonly',
      'rel',
      'required',
      'rev',
      'reversed',
      'role',
      'rows',
      'rowspan',
      'spellcheck',
      'scope',
      'selected',
      'shape',
      'size',
      'sizes',
      'slot',
      'span',
      'srclang',
      'start',
      'src',
      'srcset',
      'step',
      'style',
      'summary',
      'tabindex',
      'title',
      'translate',
      'type',
      'usemap',
      'valign',
      'value',
      'width',
      'wrap',
      'xmlns',
    ]),
    Nt = N([
      'accent-height',
      'accumulate',
      'additive',
      'alignment-baseline',
      'amplitude',
      'ascent',
      'attributename',
      'attributetype',
      'azimuth',
      'basefrequency',
      'baseline-shift',
      'begin',
      'bias',
      'by',
      'class',
      'clip',
      'clippathunits',
      'clip-path',
      'clip-rule',
      'color',
      'color-interpolation',
      'color-interpolation-filters',
      'color-profile',
      'color-rendering',
      'cx',
      'cy',
      'd',
      'dx',
      'dy',
      'diffuseconstant',
      'direction',
      'display',
      'divisor',
      'dominant-baseline',
      'dur',
      'edgemode',
      'elevation',
      'end',
      'exponent',
      'fill',
      'fill-opacity',
      'fill-rule',
      'filter',
      'filterunits',
      'flood-color',
      'flood-opacity',
      'font-family',
      'font-size',
      'font-size-adjust',
      'font-stretch',
      'font-style',
      'font-variant',
      'font-weight',
      'fx',
      'fy',
      'g1',
      'g2',
      'glyph-name',
      'glyphref',
      'gradientunits',
      'gradienttransform',
      'height',
      'href',
      'id',
      'image-rendering',
      'in',
      'in2',
      'intercept',
      'k',
      'k1',
      'k2',
      'k3',
      'k4',
      'kerning',
      'keypoints',
      'keysplines',
      'keytimes',
      'lang',
      'lengthadjust',
      'letter-spacing',
      'kernelmatrix',
      'kernelunitlength',
      'lighting-color',
      'local',
      'marker-end',
      'marker-mid',
      'marker-start',
      'markerheight',
      'markerunits',
      'markerwidth',
      'maskcontentunits',
      'maskunits',
      'max',
      'mask',
      'mask-type',
      'media',
      'method',
      'mode',
      'min',
      'name',
      'numoctaves',
      'offset',
      'operator',
      'opacity',
      'order',
      'orient',
      'orientation',
      'origin',
      'overflow',
      'paint-order',
      'path',
      'pathlength',
      'patterncontentunits',
      'patterntransform',
      'patternunits',
      'points',
      'preservealpha',
      'preserveaspectratio',
      'primitiveunits',
      'r',
      'rx',
      'ry',
      'radius',
      'refx',
      'refy',
      'repeatcount',
      'repeatdur',
      'restart',
      'result',
      'rotate',
      'scale',
      'seed',
      'shape-rendering',
      'slope',
      'specularconstant',
      'specularexponent',
      'spreadmethod',
      'startoffset',
      'stddeviation',
      'stitchtiles',
      'stop-color',
      'stop-opacity',
      'stroke-dasharray',
      'stroke-dashoffset',
      'stroke-linecap',
      'stroke-linejoin',
      'stroke-miterlimit',
      'stroke-opacity',
      'stroke',
      'stroke-width',
      'style',
      'surfacescale',
      'systemlanguage',
      'tabindex',
      'tablevalues',
      'targetx',
      'targety',
      'transform',
      'transform-origin',
      'text-anchor',
      'text-decoration',
      'text-orientation',
      'text-rendering',
      'textlength',
      'type',
      'u1',
      'u2',
      'unicode',
      'values',
      'viewbox',
      'visibility',
      'version',
      'vert-adv-y',
      'vert-origin-x',
      'vert-origin-y',
      'width',
      'word-spacing',
      'wrap',
      'writing-mode',
      'xchannelselector',
      'ychannelselector',
      'x',
      'x1',
      'x2',
      'xmlns',
      'y',
      'y1',
      'y2',
      'z',
      'zoomandpan',
    ]),
    pn = N([
      'accent',
      'accentunder',
      'align',
      'bevelled',
      'close',
      'columnalign',
      'columnlines',
      'columnspacing',
      'columnspan',
      'denomalign',
      'depth',
      'dir',
      'display',
      'displaystyle',
      'encoding',
      'fence',
      'frame',
      'height',
      'href',
      'id',
      'largeop',
      'length',
      'linethickness',
      'lquote',
      'lspace',
      'mathbackground',
      'mathcolor',
      'mathsize',
      'mathvariant',
      'maxsize',
      'minsize',
      'movablelimits',
      'notation',
      'numalign',
      'open',
      'rowalign',
      'rowlines',
      'rowspacing',
      'rowspan',
      'rspace',
      'rquote',
      'scriptlevel',
      'scriptminsize',
      'scriptsizemultiplier',
      'selection',
      'separator',
      'separators',
      'stretchy',
      'subscriptshift',
      'supscriptshift',
      'symmetric',
      'voffset',
      'width',
      'xmlns',
    ]),
    rt = N(['xlink:href', 'xml:id', 'xlink:title', 'xml:space', 'xmlns:xlink']),
    Lo = P(/{{[\w\W]*|^[\w\W]*}}/g),
    wo = P(/<%[\w\W]*|^[\w\W]*%>/g),
    No = P(/\${[\w\W]*/g),
    Po = P(/^data-[\-\w.\u00B7-\uFFFF]+$/),
    Mo = P(/^aria-[\-\w]+$/),
    dn = P(
      /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|sms|cid|xmpp|matrix):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
    ),
    xo = P(/^(?:\w+script|data):/i),
    vo = P(/[\u0000-\u0020\u00A0\u1680\u180E\u2000-\u2029\u205F\u3000]/g),
    ko = P(/^html$/i),
    Ro = P(/^[a-z][.\w]*(-[.\w]+)+$/i),
    mn = P(/<[/\w!]/g),
    gn = P(/<[/\w]/g),
    Fo = P(/<\/no(script|embed|frames)/i),
    Uo = P(/\/>/i),
    U = {
      element: 1,
      attribute: 2,
      text: 3,
      cdataSection: 4,
      entityReference: 5,
      entityNode: 6,
      processingInstruction: 7,
      comment: 8,
      document: 9,
      documentType: 10,
      documentFragment: 11,
      notation: 12,
    },
    zo = function () {
      return typeof window > 'u' ? null : window;
    },
    Ho = function (n, s) {
      if (typeof n != 'object' || typeof n.createPolicy != 'function') return null;
      let u = null,
        m = 'data-tt-policy-suffix';
      s && s.hasAttribute(m) && (u = s.getAttribute(m));
      let g = 'dompurify' + (u ? '#' + u : '');
      try {
        return n.createPolicy(g, {
          createHTML(D) {
            return D;
          },
          createScriptURL(D) {
            return D;
          },
        });
      } catch {
        return (console.warn('TrustedTypes policy ' + g + ' could not be created.'), null);
      }
    },
    hn = function () {
      return {
        afterSanitizeAttributes: [],
        afterSanitizeElements: [],
        afterSanitizeShadowDOM: [],
        beforeSanitizeAttributes: [],
        beforeSanitizeElements: [],
        beforeSanitizeShadowDOM: [],
        uponSanitizeAttribute: [],
        uponSanitizeElement: [],
        uponSanitizeShadowNode: [],
      };
    },
    ne = function (n, s, u, m) {
      return w(n, s) && oe(n[s]) ? h(m.base ? R(m.base) : {}, n[s], m.transform) : u;
    };
  function yn() {
    let o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : zo(),
      n = (a) => yn(a);
    if (
      ((n.version = '3.4.12'),
      (n.removed = []),
      !o || !o.document || o.document.nodeType !== U.document || !o.Element)
    )
      return ((n.isSupported = !1), n);
    let s = o.document,
      u = s,
      m = u.currentScript;
    o.DocumentFragment;
    let g = o.HTMLTemplateElement,
      D = o.Node,
      ae = o.Element,
      v = o.NodeFilter,
      le = o.NamedNodeMap;
    (le === void 0 && (o.NamedNodeMap || o.MozNamedAttrMap), o.HTMLFormElement);
    let Ce = o.DOMParser,
      ge = o.trustedTypes,
      Z = ae.prototype,
      at = V(Z, 'cloneNode'),
      Oe = V(Z, 'remove'),
      Ue = V(Z, 'nextSibling'),
      q = V(Z, 'childNodes'),
      H = V(Z, 'parentNode'),
      ze = V(Z, 'shadowRoot'),
      Ie = V(Z, 'attributes'),
      C = D && D.prototype ? V(D.prototype, 'nodeType') : null,
      z = D && D.prototype ? V(D.prototype, 'nodeName') : null;
    if (typeof g == 'function') {
      let a = s.createElement('template');
      a.content && a.content.ownerDocument && (s = a.content.ownerDocument);
    }
    let M,
      W = '',
      He,
      Be = !1,
      se = 0,
      De = function () {
        if (se > 0)
          throw pe(
            'A configured TRUSTED_TYPES_POLICY callback (createHTML or createScriptURL) must not call DOMPurify.sanitize, as that causes infinite recursion. Do not pass a policy whose callbacks wrap DOMPurify as TRUSTED_TYPES_POLICY; see the "DOMPurify and Trusted Types" section of the README.',
          );
      },
      K = function (e) {
        (De(), se++);
        try {
          return M.createHTML(e);
        } finally {
          se--;
        }
      },
      J = function (e) {
        (De(), se++);
        try {
          return M.createScriptURL(e);
        } finally {
          se--;
        }
      },
      lt = function () {
        return (Be || ((He = Ho(ge, m)), (Be = !0)), He);
      },
      ce = s,
      Le = ce.implementation,
      Ge = ce.createNodeIterator,
      We = ce.createDocumentFragment,
      je = ce.getElementsByTagName,
      vt = u.importNode,
      A = hn();
    n.isSupported =
      typeof Tn == 'function' && typeof H == 'function' && Le && Le.createHTMLDocument !== void 0;
    let st = Lo,
      Ye = wo,
      $e = No,
      Xe = Po,
      Ve = Mo,
      Ze = xo,
      we = vo,
      qe = Ro,
      Ne = dn,
      y = null,
      Pe = h({}, [...cn, ...Dt, ...Lt, ...wt, ...un]),
      b = null,
      l = h({}, [...fn, ...Nt, ...pn, ...rt]),
      p = Object.seal(
        Se(null, {
          tagNameCheck: { writable: !0, configurable: !1, enumerable: !0, value: null },
          attributeNameCheck: { writable: !0, configurable: !1, enumerable: !0, value: null },
          allowCustomizedBuiltInElements: {
            writable: !0,
            configurable: !1,
            enumerable: !0,
            value: !1,
          },
        }),
      ),
      I = null,
      j = null,
      _ = Object.seal(
        Se(null, {
          tagCheck: { writable: !0, configurable: !1, enumerable: !0, value: null },
          attributeCheck: { writable: !0, configurable: !1, enumerable: !0, value: null },
        }),
      ),
      kt = !0,
      ct = !0,
      Rt = !1,
      Ft = !0,
      Q = !1,
      ee = !0,
      ue = !1,
      ut = !1,
      ft = null,
      pt = null,
      dt = !1,
      he = !1,
      Ke = !1,
      Je = !1,
      Ut = !0,
      zt = !1,
      Ht = 'user-content-',
      mt = !0,
      gt = !1,
      Te = {},
      Y = null,
      ht = h({}, [
        'annotation-xml',
        'audio',
        'colgroup',
        'desc',
        'foreignobject',
        'head',
        'iframe',
        'math',
        'mi',
        'mn',
        'mo',
        'ms',
        'mtext',
        'noembed',
        'noframes',
        'noscript',
        'plaintext',
        'script',
        'selectedcontent',
        'style',
        'svg',
        'template',
        'thead',
        'title',
        'video',
        'xmp',
      ]),
      Bt = null,
      Gt = h({}, ['audio', 'video', 'img', 'source', 'image', 'track']),
      Tt = null,
      Wt = h({}, [
        'alt',
        'class',
        'for',
        'id',
        'label',
        'name',
        'pattern',
        'placeholder',
        'role',
        'summary',
        'title',
        'value',
        'style',
        'xmlns',
      ]),
      Qe = 'http://www.w3.org/1998/Math/MathML',
      et = 'http://www.w3.org/2000/svg',
      $ = 'http://www.w3.org/1999/xhtml',
      _e = $,
      _t = !1,
      yt = null,
      $n = h({}, [Qe, et, $], It),
      jt = N(['mi', 'mo', 'mn', 'ms', 'mtext']),
      bt = h({}, jt),
      Yt = N(['annotation-xml']),
      At = h({}, Yt),
      Xn = h({}, ['title', 'style', 'font', 'a', 'script']),
      Me = null,
      Vn = ['application/xhtml+xml', 'text/html'],
      Zn = 'text/html',
      E = null,
      ye = null,
      qn = s.createElement('form'),
      $t = function (e) {
        return e instanceof RegExp || e instanceof Function;
      },
      Et = function () {
        let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        if (ye && ye === e) return;
        ((!e || typeof e != 'object') && (e = {}),
          (e = R(e)),
          (Me = Vn.indexOf(e.PARSER_MEDIA_TYPE) === -1 ? Zn : e.PARSER_MEDIA_TYPE),
          (E = Me === 'application/xhtml+xml' ? It : Re),
          (y = ne(e, 'ALLOWED_TAGS', Pe, { transform: E })),
          (b = ne(e, 'ALLOWED_ATTR', l, { transform: E })),
          (yt = ne(e, 'ALLOWED_NAMESPACES', $n, { transform: It })),
          (Tt = ne(e, 'ADD_URI_SAFE_ATTR', Wt, { transform: E, base: Wt })),
          (Bt = ne(e, 'ADD_DATA_URI_TAGS', Gt, { transform: E, base: Gt })),
          (Y = ne(e, 'FORBID_CONTENTS', ht, { transform: E })),
          (I = ne(e, 'FORBID_TAGS', R({}), { transform: E })),
          (j = ne(e, 'FORBID_ATTR', R({}), { transform: E })),
          (Te = w(e, 'USE_PROFILES')
            ? e.USE_PROFILES && typeof e.USE_PROFILES == 'object'
              ? R(e.USE_PROFILES)
              : e.USE_PROFILES
            : !1),
          (kt = e.ALLOW_ARIA_ATTR !== !1),
          (ct = e.ALLOW_DATA_ATTR !== !1),
          (Rt = e.ALLOW_UNKNOWN_PROTOCOLS || !1),
          (Ft = e.ALLOW_SELF_CLOSE_IN_ATTR !== !1),
          (Q = e.SAFE_FOR_TEMPLATES || !1),
          (ee = e.SAFE_FOR_XML !== !1),
          (ue = e.WHOLE_DOCUMENT || !1),
          (he = e.RETURN_DOM || !1),
          (Ke = e.RETURN_DOM_FRAGMENT || !1),
          (Je = e.RETURN_TRUSTED_TYPE || !1),
          (dt = e.FORCE_BODY || !1),
          (Ut = e.SANITIZE_DOM !== !1),
          (zt = e.SANITIZE_NAMED_PROPS || !1),
          (mt = e.KEEP_CONTENT !== !1),
          (gt = e.IN_PLACE || !1),
          (Ne = Oo(e.ALLOWED_URI_REGEXP) ? e.ALLOWED_URI_REGEXP : dn),
          (_e = typeof e.NAMESPACE == 'string' ? e.NAMESPACE : $),
          (bt =
            w(e, 'MATHML_TEXT_INTEGRATION_POINTS') &&
            e.MATHML_TEXT_INTEGRATION_POINTS &&
            typeof e.MATHML_TEXT_INTEGRATION_POINTS == 'object'
              ? R(e.MATHML_TEXT_INTEGRATION_POINTS)
              : h({}, jt)),
          (At =
            w(e, 'HTML_INTEGRATION_POINTS') &&
            e.HTML_INTEGRATION_POINTS &&
            typeof e.HTML_INTEGRATION_POINTS == 'object'
              ? R(e.HTML_INTEGRATION_POINTS)
              : h({}, Yt)));
        let t =
          w(e, 'CUSTOM_ELEMENT_HANDLING') &&
          e.CUSTOM_ELEMENT_HANDLING &&
          typeof e.CUSTOM_ELEMENT_HANDLING == 'object'
            ? R(e.CUSTOM_ELEMENT_HANDLING)
            : Se(null);
        if (
          ((p = Se(null)),
          w(t, 'tagNameCheck') && $t(t.tagNameCheck) && (p.tagNameCheck = t.tagNameCheck),
          w(t, 'attributeNameCheck') &&
            $t(t.attributeNameCheck) &&
            (p.attributeNameCheck = t.attributeNameCheck),
          w(t, 'allowCustomizedBuiltInElements') &&
            typeof t.allowCustomizedBuiltInElements == 'boolean' &&
            (p.allowCustomizedBuiltInElements = t.allowCustomizedBuiltInElements),
          P(p),
          Q && (ct = !1),
          Ke && (he = !0),
          Te &&
            ((y = h({}, un)),
            (b = Se(null)),
            Te.html === !0 && (h(y, cn), h(b, fn)),
            Te.svg === !0 && (h(y, Dt), h(b, Nt), h(b, rt)),
            Te.svgFilters === !0 && (h(y, Lt), h(b, Nt), h(b, rt)),
            Te.mathMl === !0 && (h(y, wt), h(b, pn), h(b, rt))),
          (_.tagCheck = null),
          (_.attributeCheck = null),
          w(e, 'ADD_TAGS') &&
            (typeof e.ADD_TAGS == 'function'
              ? (_.tagCheck = e.ADD_TAGS)
              : oe(e.ADD_TAGS) && (y === Pe && (y = R(y)), h(y, e.ADD_TAGS, E))),
          w(e, 'ADD_ATTR') &&
            (typeof e.ADD_ATTR == 'function'
              ? (_.attributeCheck = e.ADD_ATTR)
              : oe(e.ADD_ATTR) && (b === l && (b = R(b)), h(b, e.ADD_ATTR, E))),
          w(e, 'ADD_URI_SAFE_ATTR') && oe(e.ADD_URI_SAFE_ATTR) && h(Tt, e.ADD_URI_SAFE_ATTR, E),
          w(e, 'FORBID_CONTENTS') &&
            oe(e.FORBID_CONTENTS) &&
            (Y === ht && (Y = R(Y)), h(Y, e.FORBID_CONTENTS, E)),
          w(e, 'ADD_FORBID_CONTENTS') &&
            oe(e.ADD_FORBID_CONTENTS) &&
            (Y === ht && (Y = R(Y)), h(Y, e.ADD_FORBID_CONTENTS, E)),
          mt && (y['#text'] = !0),
          ue && h(y, ['html', 'head', 'body']),
          y.table && (h(y, ['tbody']), delete I.tbody),
          e.TRUSTED_TYPES_POLICY)
        ) {
          if (typeof e.TRUSTED_TYPES_POLICY.createHTML != 'function')
            throw pe('TRUSTED_TYPES_POLICY configuration option must provide a "createHTML" hook.');
          if (typeof e.TRUSTED_TYPES_POLICY.createScriptURL != 'function')
            throw pe(
              'TRUSTED_TYPES_POLICY configuration option must provide a "createScriptURL" hook.',
            );
          let i = M;
          M = e.TRUSTED_TYPES_POLICY;
          try {
            W = K('');
          } catch (c) {
            throw ((M = i), c);
          }
        } else
          e.TRUSTED_TYPES_POLICY === null
            ? ((M = void 0), (W = ''))
            : (M === void 0 && (M = lt()), M && typeof W == 'string' && (W = K('')));
        (N && N(e), (ye = e));
      },
      Xt = h({}, [...Dt, ...Lt, ...Io]),
      Vt = h({}, [...wt, ...Do]),
      Kn = function (e, t, i) {
        return t.namespaceURI === $
          ? e === 'svg'
          : t.namespaceURI === Qe
            ? e === 'svg' && (i === 'annotation-xml' || bt[i])
            : !!Xt[e];
      },
      Jn = function (e, t, i) {
        return t.namespaceURI === $
          ? e === 'math'
          : t.namespaceURI === et
            ? e === 'math' && At[i]
            : !!Vt[e];
      },
      Qn = function (e, t, i) {
        return (t.namespaceURI === et && !At[i]) || (t.namespaceURI === Qe && !bt[i])
          ? !1
          : !Vt[e] && (Xn[e] || !Xt[e]);
      },
      eo = function (e) {
        let t = H(e);
        (!t || !t.tagName) && (t = { namespaceURI: _e, tagName: 'template' });
        let i = Re(e.tagName),
          c = Re(t.tagName);
        return yt[e.namespaceURI]
          ? e.namespaceURI === et
            ? Kn(i, t, c)
            : e.namespaceURI === Qe
              ? Jn(i, t, c)
              : e.namespaceURI === $
                ? Qn(i, t, c)
                : !!(Me === 'application/xhtml+xml' && yt[e.namespaceURI])
          : !1;
      },
      te = function (e) {
        Ee(n.removed, { element: e });
        try {
          H(e).removeChild(e);
        } catch {
          if ((Oe(e), !H(e)))
            throw pe(
              'a node selected for removal could not be detached from its tree and cannot be safely returned; refusing to sanitize in place',
            );
        }
      },
      tt = function (e) {
        St(e);
        let t = q(e);
        if (t) {
          let c = [];
          (Ae(t, (f) => {
            Ee(c, f);
          }),
            Ae(c, (f) => {
              try {
                Oe(f);
              } catch {}
            }));
        }
        let i = Ie(e);
        if (i)
          for (let c = i.length - 1; c >= 0; --c) {
            let f = i[c],
              d = f && f.name;
            if (typeof d == 'string')
              try {
                e.removeAttribute(d);
              } catch {}
          }
      },
      fe = function (e, t) {
        try {
          Ee(n.removed, { attribute: t.getAttributeNode(e), from: t });
        } catch {
          Ee(n.removed, { attribute: null, from: t });
        }
        if ((t.removeAttribute(e), e === 'is'))
          if (he || Ke)
            try {
              te(t);
            } catch {}
          else
            try {
              t.setAttribute(e, '');
            } catch {}
      },
      to = function (e) {
        let t = Ie(e);
        if (t)
          for (let i = t.length - 1; i >= 0; --i) {
            let c = t[i],
              f = c && c.name;
            if (!(typeof f != 'string' || b[E(f)]))
              try {
                e.removeAttribute(f);
              } catch {}
          }
      },
      St = function (e) {
        let t = [e];
        for (; t.length > 0;) {
          let i = t.pop();
          (C ? C(i) : i.nodeType) === U.element && to(i);
          let f = q(i);
          if (f) for (let d = f.length - 1; d >= 0; --d) t.push(f[d]);
        }
      },
      no = function (e) {
        if (!ee) return;
        let t = [e];
        for (; t.length > 0;) {
          let i = t.pop(),
            c = C ? C(i) : i.nodeType;
          if (c === U.processingInstruction || (c === U.comment && L(gn, i.data))) {
            try {
              Oe(i);
            } catch {}
            continue;
          }
          if (c === U.element) {
            let d = i,
              S = E(z ? z(i) : i.nodeName);
            try {
              (d.hasAttribute && d.hasAttribute('patchsrc') && d.removeAttribute('patchsrc'),
                d.hasAttribute &&
                  d.hasAttribute('for') &&
                  S !== 'label' &&
                  S !== 'output' &&
                  d.removeAttribute('for'));
            } catch {}
          }
          let f = q(i);
          if (f) for (let d = f.length - 1; d >= 0; --d) t.push(f[d]);
        }
      },
      Zt = function (e) {
        let t = null,
          i = null;
        if (dt) e = '<remove></remove>' + e;
        else {
          let d = rn(e, /^[\r\n\t ]+/);
          i = d && d[0];
        }
        Me === 'application/xhtml+xml' &&
          _e === $ &&
          (e =
            '<html xmlns="http://www.w3.org/1999/xhtml"><head></head><body>' +
            e +
            '</body></html>');
        let c = M ? K(e) : e;
        if (_e === $)
          try {
            t = new Ce().parseFromString(c, Me);
          } catch {}
        if (!t || !t.documentElement) {
          t = Le.createDocument(_e, 'template', null);
          try {
            t.documentElement.innerHTML = _t ? W : c;
          } catch {}
        }
        let f = t.body || t.documentElement;
        return (
          e && i && f.insertBefore(s.createTextNode(i), f.childNodes[0] || null),
          _e === $ ? je.call(t, ue ? 'html' : 'body')[0] : ue ? t.documentElement : f
        );
      },
      qt = function (e) {
        return Ge.call(
          e.ownerDocument || e,
          e,
          v.SHOW_ELEMENT |
            v.SHOW_COMMENT |
            v.SHOW_TEXT |
            v.SHOW_PROCESSING_INSTRUCTION |
            v.SHOW_CDATA_SECTION,
          null,
        );
      },
      nt = function (e) {
        return ((e = ve(e, st, ' ')), (e = ve(e, Ye, ' ')), (e = ve(e, $e, ' ')), e);
      },
      Ct = function (e) {
        var t;
        e.normalize();
        let i = Ge.call(
            e.ownerDocument || e,
            e,
            v.SHOW_TEXT | v.SHOW_COMMENT | v.SHOW_CDATA_SECTION | v.SHOW_PROCESSING_INSTRUCTION,
            null,
          ),
          c = i.nextNode();
        for (; c;) ((c.data = nt(c.data)), (c = i.nextNode()));
        let f = (t = e.querySelectorAll) === null || t === void 0 ? void 0 : t.call(e, 'template');
        f &&
          Ae(f, (d) => {
            be(d.content) && Ct(d.content);
          });
      },
      ot = function (e) {
        let t = z ? z(e) : null;
        return typeof t != 'string' || E(t) !== 'form'
          ? !1
          : typeof e.nodeName != 'string' ||
              typeof e.textContent != 'string' ||
              typeof e.removeChild != 'function' ||
              e.attributes !== Ie(e) ||
              typeof e.removeAttribute != 'function' ||
              typeof e.setAttribute != 'function' ||
              typeof e.namespaceURI != 'string' ||
              typeof e.insertBefore != 'function' ||
              typeof e.hasChildNodes != 'function' ||
              e.nodeType !== C(e) ||
              e.childNodes !== q(e);
      },
      be = function (e) {
        if (!C || typeof e != 'object' || e === null) return !1;
        try {
          return C(e) === U.documentFragment;
        } catch {
          return !1;
        }
      },
      xe = function (e) {
        if (!C || typeof e != 'object' || e === null) return !1;
        try {
          return typeof C(e) == 'number';
        } catch {
          return !1;
        }
      };
    function X(a, e, t) {
      a.length !== 0 &&
        Ae(a, (i) => {
          i.call(n, e, t, ye);
        });
    }
    let oo = function (e, t) {
        return !!(
          (ee &&
            e.hasChildNodes() &&
            !xe(e.firstElementChild) &&
            L(mn, e.textContent) &&
            L(mn, e.innerHTML)) ||
          (ee && e.namespaceURI === $ && t === 'style' && xe(e.firstElementChild)) ||
          e.nodeType === U.processingInstruction ||
          (ee && e.nodeType === U.comment && L(gn, e.data))
        );
      },
      io = function (e, t) {
        if (
          !I[t] &&
          Qt(t) &&
          ((p.tagNameCheck instanceof RegExp && L(p.tagNameCheck, t)) ||
            (p.tagNameCheck instanceof Function && p.tagNameCheck(t)))
        )
          return !1;
        if (mt && !Y[t]) {
          let i = H(e),
            c = q(e);
          if (c && i) {
            let f = c.length;
            for (let d = f - 1; d >= 0; --d) {
              let S = gt ? c[d] : at(c[d], !0);
              i.insertBefore(S, Ue(e));
            }
          }
        }
        return (te(e), !0);
      },
      Kt = function (e, t) {
        if ((X(A.beforeSanitizeElements, e, null), e !== t && H(e) === null)) return !0;
        if (ot(e)) return (te(e), !0);
        let i = E(z ? z(e) : e.nodeName);
        if ((X(A.uponSanitizeElement, e, { tagName: i, allowedTags: y }), e !== t && H(e) === null))
          return !0;
        if (oo(e, i)) return (te(e), !0);
        if (I[i] || (!(_.tagCheck instanceof Function && _.tagCheck(i)) && !y[i])) {
          let f = io(e, i);
          return (f === !1 && X(A.afterSanitizeElements, e, null), f);
        }
        if (
          ((C ? C(e) : e.nodeType) === U.element && !eo(e)) ||
          ((i === 'noscript' || i === 'noembed' || i === 'noframes') && L(Fo, e.innerHTML))
        )
          return (te(e), !0);
        if (Q && e.nodeType === U.text) {
          let f = nt(e.textContent);
          e.textContent !== f && (Ee(n.removed, { element: e.cloneNode() }), (e.textContent = f));
        }
        return (X(A.afterSanitizeElements, e, null), !1);
      },
      Jt = function (e, t, i) {
        if (
          j[t] ||
          (ee && t === 'patchsrc') ||
          (ee && t === 'for' && e !== 'label' && e !== 'output') ||
          (Ut && (t === 'id' || t === 'name') && (i in s || i in qn))
        )
          return !1;
        let c = b[t] || (_.attributeCheck instanceof Function && _.attributeCheck(t, e));
        if (!(ct && L(Xe, t))) {
          if (!(kt && L(Ve, t))) {
            if (c) {
              if (!Tt[t]) {
                if (!L(Ne, ve(i, we, ''))) {
                  if (!(
                    (t === 'src' || t === 'xlink:href' || t === 'href') &&
                    e !== 'script' &&
                    an(i, 'data:') === 0 &&
                    Bt[e]
                  )) {
                    if (!(Rt && !L(Ze, ve(i, we, '')))) {
                      if (i) return !1;
                    }
                  }
                }
              }
            } else if (!(
              (Qt(e) &&
                ((p.tagNameCheck instanceof RegExp && L(p.tagNameCheck, e)) ||
                  (p.tagNameCheck instanceof Function && p.tagNameCheck(e))) &&
                ((p.attributeNameCheck instanceof RegExp && L(p.attributeNameCheck, t)) ||
                  (p.attributeNameCheck instanceof Function && p.attributeNameCheck(t, e)))) ||
              (t === 'is' &&
                p.allowCustomizedBuiltInElements &&
                ((p.tagNameCheck instanceof RegExp && L(p.tagNameCheck, i)) ||
                  (p.tagNameCheck instanceof Function && p.tagNameCheck(i))))
            ))
              return !1;
          }
        }
        return !0;
      },
      ro = h({}, [
        'annotation-xml',
        'color-profile',
        'font-face',
        'font-face-format',
        'font-face-name',
        'font-face-src',
        'font-face-uri',
        'missing-glyph',
      ]),
      Qt = function (e) {
        return !ro[Re(e)] && L(qe, e);
      },
      ao = function (e, t, i, c) {
        if (M && typeof ge == 'object' && typeof ge.getAttributeType == 'function' && !i)
          switch (ge.getAttributeType(e, t)) {
            case 'TrustedHTML':
              return K(c);
            case 'TrustedScriptURL':
              return J(c);
          }
        return c;
      },
      lo = function (e, t, i, c) {
        try {
          (i ? e.setAttributeNS(i, t, c) : e.setAttribute(t, c), ot(e) ? te(e) : on(n.removed));
        } catch {
          fe(t, e);
        }
      },
      en = function (e) {
        X(A.beforeSanitizeAttributes, e, null);
        let t = e.attributes;
        if (!t || ot(e)) return;
        let i = {
            attrName: '',
            attrValue: '',
            keepAttr: !0,
            allowedAttributes: b,
            forceKeepAttr: void 0,
          },
          c = t.length,
          f = E(e.nodeName);
        for (; c--;) {
          let d = t[c],
            S = d.name,
            x = d.namespaceURI,
            B = d.value,
            F = E(S),
            G = B,
            k = S === 'value' ? G : yo(G);
          if (
            ((i.attrName = F),
            (i.attrValue = k),
            (i.keepAttr = !0),
            (i.forceKeepAttr = void 0),
            X(A.uponSanitizeAttribute, e, i),
            (k = i.attrValue),
            zt && (F === 'id' || F === 'name') && an(k, Ht) !== 0 && (fe(S, e), (k = Ht + k)),
            ee &&
              L(
                /((--!?|])>)|<\/(style|script|title|xmp|textarea|noscript|iframe|noembed|noframes)/i,
                k,
              ))
          ) {
            fe(S, e);
            continue;
          }
          if (F === 'attributename' && rn(k, 'href')) {
            fe(S, e);
            continue;
          }
          if (!i.forceKeepAttr) {
            if (!i.keepAttr) {
              fe(S, e);
              continue;
            }
            if (!Ft && L(Uo, k)) {
              fe(S, e);
              continue;
            }
            if ((Q && (k = nt(k)), !Jt(f, F, k))) {
              fe(S, e);
              continue;
            }
            ((k = ao(f, F, x, k)), k !== G && lo(e, S, x, k));
          }
        }
        X(A.afterSanitizeAttributes, e, null);
      },
      it = function (e) {
        let t = null,
          i = qt(e);
        for (X(A.beforeSanitizeShadowDOM, e, null); (t = i.nextNode());)
          if (
            (X(A.uponSanitizeShadowNode, t, null),
            Kt(t, e),
            en(t),
            be(t.content) && it(t.content),
            (C ? C(t) : t.nodeType) === U.element)
          ) {
            let f = ze(t);
            be(f) && (Ot(f), it(f));
          }
        X(A.afterSanitizeShadowDOM, e, null);
      },
      Ot = function (e) {
        let t = [{ node: e, shadow: null }];
        for (; t.length > 0;) {
          let i = t.pop();
          if (i.shadow) {
            it(i.shadow);
            continue;
          }
          let c = i.node,
            d = (C ? C(c) : c.nodeType) === U.element,
            S = q(c);
          if (S) for (let x = S.length - 1; x >= 0; --x) t.push({ node: S[x], shadow: null });
          if (d) {
            let x = z ? z(c) : null;
            if (typeof x == 'string' && E(x) === 'template') {
              let B = c.content;
              be(B) && t.push({ node: B, shadow: null });
            }
          }
          if (d) {
            let x = ze(c);
            be(x) && t.push({ node: null, shadow: x }, { node: x, shadow: null });
          }
        }
      };
    return (
      (n.sanitize = function (a) {
        let e = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
          t = null,
          i = null,
          c = null,
          f = null;
        if (
          ((_t = !a),
          _t && (a = '<!-->'),
          typeof a != 'string' && !xe(a) && ((a = Co(a)), typeof a != 'string'))
        )
          throw pe('dirty is not a string, aborting');
        if (!n.isSupported) return a;
        (ut ? ((y = ft), (b = pt)) : Et(e),
          (A.uponSanitizeElement.length > 0 || A.uponSanitizeAttribute.length > 0) && (y = R(y)),
          A.uponSanitizeAttribute.length > 0 && (b = R(b)),
          (n.removed = []));
        let d = gt && typeof a != 'string' && xe(a);
        if (d) {
          no(a);
          let F = z ? z(a) : a.nodeName;
          if (typeof F == 'string') {
            let G = E(F);
            if (!y[G] || I[G])
              throw (tt(a), pe('root node is forbidden and cannot be sanitized in-place'));
          }
          if (ot(a)) throw (tt(a), pe('root node is clobbered and cannot be sanitized in-place'));
          try {
            Ot(a);
          } catch (G) {
            throw (tt(a), G);
          }
        } else if (xe(a))
          ((t = Zt('<!---->')),
            (i = t.ownerDocument.importNode(a, !0)),
            (i.nodeType === U.element && i.nodeName === 'BODY') || i.nodeName === 'HTML'
              ? (t = i)
              : t.appendChild(i),
            Ot(i));
        else {
          if (!he && !Q && !ue && a.indexOf('<') === -1) return M && Je ? K(a) : a;
          if (((t = Zt(a)), !t)) return he ? null : Je ? W : '';
        }
        t && dt && te(t.firstChild);
        let S = d ? a : t,
          x = qt(S);
        try {
          for (; (c = x.nextNode());) (Kt(c, S), en(c), be(c.content) && it(c.content));
        } catch (F) {
          throw (
            d &&
              (tt(a),
              Ae(n.removed, (G) => {
                G.element && St(G.element);
              })),
            F
          );
        }
        if (d)
          return (
            Ae(n.removed, (F) => {
              F.element && St(F.element);
            }),
            Q && Ct(a),
            a
          );
        if (he) {
          if ((Q && Ct(t), Ke))
            for (f = We.call(t.ownerDocument); t.firstChild;) f.appendChild(t.firstChild);
          else f = t;
          return ((b.shadowroot || b.shadowrootmode) && (f = vt.call(u, f, !0)), f);
        }
        let B = ue ? t.outerHTML : t.innerHTML;
        return (
          ue &&
            y['!doctype'] &&
            t.ownerDocument &&
            t.ownerDocument.doctype &&
            t.ownerDocument.doctype.name &&
            L(ko, t.ownerDocument.doctype.name) &&
            (B =
              '<!DOCTYPE ' +
              t.ownerDocument.doctype.name +
              `>
` +
              B),
          Q && (B = nt(B)),
          M && Je ? K(B) : B
        );
      }),
      (n.setConfig = function () {
        let a = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
        (Et(a), (ut = !0), (ft = y), (pt = b));
      }),
      (n.clearConfig = function () {
        ((ye = null), (ut = !1), (ft = null), (pt = null), (M = He), (W = ''));
      }),
      (n.isValidAttribute = function (a, e, t) {
        ye || Et({});
        let i = E(a),
          c = E(e);
        return Jt(i, c, t);
      }),
      (n.addHook = function (a, e) {
        typeof e == 'function' && w(A, a) && Ee(A[a], e);
      }),
      (n.removeHook = function (a, e) {
        if (w(A, a)) {
          if (e !== void 0) {
            let t = To(A[a], e);
            return t === -1 ? void 0 : _o(A[a], t, 1)[0];
          }
          return on(A[a]);
        }
      }),
      (n.removeHooks = function (a) {
        w(A, a) && (A[a] = []);
      }),
      (n.removeAllHooks = function () {
        A = hn();
      }),
      n
    );
  }
  var bn = yn();
  var { registerBlockType: Bo } = wp.blocks,
    r = wp.element,
    { useState: de, useEffect: An } = wp.element,
    me = window.jQuery,
    { InspectorControls: Go } = wp.blockEditor,
    { __: T } = wp.i18n,
    {
      PanelBody: En,
      TextControl: Fe,
      BaseControl: xt,
      SelectControl: ie,
      CheckboxControl: re,
      Card: Wo,
      CardBody: jo,
    } = wp.components,
    Yo = () =>
      r.createElement(
        'svg',
        {
          'aria-hidden': 'true',
          width: '14',
          height: '14',
          viewBox: '0 0 24 24',
          className: 'sortable-item-handle',
        },
        r.createElement('circle', { cx: '5', cy: '6', r: '2' }),
        r.createElement('circle', { cx: '5', cy: '12', r: '2' }),
        r.createElement('circle', { cx: '5', cy: '18', r: '2' }),
        r.createElement('circle', { cx: '13', cy: '6', r: '2' }),
        r.createElement('circle', { cx: '13', cy: '12', r: '2' }),
        r.createElement('circle', { cx: '13', cy: '18', r: '2' }),
      ),
    Yn = (o) =>
      o
        .children('li')
        .map(function () {
          let n = me(this),
            s = n.data('term-id'),
            u = n.find('> div > ul.categories-all-in-one-sortable-item-children-container');
          return { term_id: s, children: u.length ? Yn(u) : [] };
        })
        .get(),
    $o = (o) => (Array.isArray(o) && o.length ? o : typeof o == 'string' ? [o] : []),
    Xo = () =>
      r.createElement(
        'svg',
        {
          width: '24',
          height: '24',
          xmlns: 'http://www.w3.org/2000/svg',
          viewBox: '0 0 156 180.749997',
          version: '1.0',
        },
        r.createElement(
          'defs',
          null,
          r.createElement(
            'clipPath',
            { id: 'a556d4b536' },
            r.createElement('path', {
              d: 'M 0.109375 0 L 155.890625 0 L 155.890625 36.699219 L 0.109375 36.699219 Z M 0.109375 0 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: 'ebe200ac89' },
            r.createElement('path', {
              d: 'M 7.597656 0 L 148.402344 0 C 150.390625 0 152.292969 0.789062 153.699219 2.195312 C 155.101562 3.597656 155.890625 5.503906 155.890625 7.488281 L 155.890625 29.210938 C 155.890625 31.195312 155.101562 33.101562 153.699219 34.503906 C 152.292969 35.910156 150.390625 36.699219 148.402344 36.699219 L 7.597656 36.699219 C 5.609375 36.699219 3.707031 35.910156 2.300781 34.503906 C 0.898438 33.101562 0.109375 31.195312 0.109375 29.210938 L 0.109375 7.488281 C 0.109375 5.503906 0.898438 3.597656 2.300781 2.195312 C 3.707031 0.789062 5.609375 0 7.597656 0 Z M 7.597656 0 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: '55d81177cc' },
            r.createElement('path', {
              d: 'M 0.109375 47.933594 L 155.890625 47.933594 L 155.890625 84.632812 L 0.109375 84.632812 Z M 0.109375 47.933594 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: 'dee4119813' },
            r.createElement('path', {
              d: 'M 7.597656 47.933594 L 148.402344 47.933594 C 150.390625 47.933594 152.292969 48.722656 153.699219 50.128906 C 155.101562 51.53125 155.890625 53.4375 155.890625 55.421875 L 155.890625 77.144531 C 155.890625 79.128906 155.101562 81.035156 153.699219 82.4375 C 152.292969 83.84375 150.390625 84.632812 148.402344 84.632812 L 7.597656 84.632812 C 5.609375 84.632812 3.707031 83.84375 2.300781 82.4375 C 0.898438 81.035156 0.109375 79.128906 0.109375 77.144531 L 0.109375 55.421875 C 0.109375 53.4375 0.898438 51.53125 2.300781 50.128906 C 3.707031 48.722656 5.609375 47.933594 7.597656 47.933594 Z M 7.597656 47.933594 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: 'ccd03e30d1' },
            r.createElement('path', {
              d: 'M 0.109375 95.867188 L 155.890625 95.867188 L 155.890625 132.566406 L 0.109375 132.566406 Z M 0.109375 95.867188 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: '756047783d' },
            r.createElement('path', {
              d: 'M 7.597656 95.867188 L 148.402344 95.867188 C 150.390625 95.867188 152.292969 96.65625 153.699219 98.0625 C 155.101562 99.464844 155.890625 101.371094 155.890625 103.355469 L 155.890625 125.078125 C 155.890625 127.0625 155.101562 128.96875 153.699219 130.371094 C 152.292969 131.777344 150.390625 132.566406 148.402344 132.566406 L 7.597656 132.566406 C 5.609375 132.566406 3.707031 131.777344 2.300781 130.371094 C 0.898438 128.96875 0.109375 127.0625 0.109375 125.078125 L 0.109375 103.355469 C 0.109375 101.371094 0.898438 99.464844 2.300781 98.0625 C 3.707031 96.65625 5.609375 95.867188 7.597656 95.867188 Z M 7.597656 95.867188 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: 'a2e8422a23' },
            r.createElement('path', {
              d: 'M 0.109375 143.800781 L 155.890625 143.800781 L 155.890625 180.5 L 0.109375 180.5 Z M 0.109375 143.800781 ',
              clipRule: 'nonzero',
            }),
          ),
          r.createElement(
            'clipPath',
            { id: 'e200df5dc7' },
            r.createElement('path', {
              d: 'M 7.597656 143.800781 L 148.402344 143.800781 C 150.390625 143.800781 152.292969 144.589844 153.699219 145.996094 C 155.101562 147.398438 155.890625 149.304688 155.890625 151.289062 L 155.890625 173.011719 C 155.890625 174.996094 155.101562 176.902344 153.699219 178.308594 C 152.292969 179.710938 150.390625 180.5 148.402344 180.5 L 7.597656 180.5 C 5.609375 180.5 3.707031 179.710938 2.300781 178.308594 C 0.898438 176.902344 0.109375 174.996094 0.109375 173.011719 L 0.109375 151.289062 C 0.109375 149.304688 0.898438 147.398438 2.300781 145.996094 C 3.707031 144.589844 5.609375 143.800781 7.597656 143.800781 Z M 7.597656 143.800781 ',
              clipRule: 'nonzero',
            }),
          ),
        ),
        r.createElement(
          'g',
          { 'clip-path': 'url(#a556d4b536)' },
          r.createElement(
            'g',
            { 'clip-path': 'url(#ebe200ac89)' },
            r.createElement('path', {
              fill: '#65c9be',
              d: 'M 0.109375 0 L 155.9375 0 L 155.9375 36.699219 L 0.109375 36.699219 Z M 0.109375 0 ',
              fillOpacity: '1',
              fillRule: 'nonzero',
            }),
          ),
        ),
        r.createElement(
          'g',
          { 'clip-path': 'url(#55d81177cc)' },
          r.createElement(
            'g',
            { 'clip-path': 'url(#dee4119813)' },
            r.createElement('path', {
              fill: '#65c9be',
              d: 'M 0.109375 47.933594 L 155.9375 47.933594 L 155.9375 84.632812 L 0.109375 84.632812 Z M 0.109375 47.933594 ',
              fillOpacity: '1',
              fillRule: 'nonzero',
            }),
          ),
        ),
        r.createElement(
          'g',
          { 'clip-path': 'url(#ccd03e30d1)' },
          r.createElement(
            'g',
            { 'clip-path': 'url(#756047783d)' },
            r.createElement('path', {
              fill: '#65c9be',
              d: 'M 0.109375 95.867188 L 155.9375 95.867188 L 155.9375 132.566406 L 0.109375 132.566406 Z M 0.109375 95.867188 ',
              fillOpacity: '1',
              fillRule: 'nonzero',
            }),
          ),
        ),
        r.createElement(
          'g',
          { 'clip-path': 'url(#a2e8422a23)' },
          r.createElement(
            'g',
            { 'clip-path': 'url(#e200df5dc7)' },
            r.createElement('path', {
              fill: '#65c9be',
              d: 'M 0.109375 143.800781 L 155.9375 143.800781 L 155.9375 180.5 L 0.109375 180.5 Z M 0.109375 143.800781 ',
              fillOpacity: '1',
              fillRule: 'nonzero',
            }),
          ),
        ),
      ),
    Sn,
    Cn,
    On,
    In,
    Dn,
    Ln,
    wn,
    Nn,
    Pn,
    Mn,
    xn,
    vn,
    kn,
    Rn,
    Fn,
    Un,
    zn,
    Hn,
    Bn,
    Gn,
    Wn,
    jn;
  Bo('categories-all-in-one/block', {
    title: 'Categories All In One',
    description: T(
      'Display customizable category list from selected taxonomies with various sorting and styling options',
      'categories-all-in-one',
    ),
    category: 'common',
    icon: Xo,
    supports: { customClassName: !1 },
    attributes: {
      lang: {
        type: 'string',
        default:
          ((Sn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Sn.defaults.lang) !== ''
            ? (Cn =
                CategoriesAllInOnePluginData == null
                  ? void 0
                  : CategoriesAllInOnePluginData.dictionaries) == null
              ? void 0
              : Cn.defaults.lang
            : CategoriesAllInOnePluginData.locale,
      },
      list: {
        type: 'string',
        default:
          (On =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : On.defaults.list,
      },
      layout: {
        type: 'string',
        default:
          (In =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : In.defaults.layout,
      },
      columns: {
        type: 'number',
        default:
          (Dn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Dn.defaults.columns,
      },
      separator: {
        type: 'string',
        default:
          (Ln =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Ln.defaults.separator,
      },
      hide_empty: {
        type: 'boolean',
        default:
          (wn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : wn.defaults.hide_empty,
      },
      show_count: {
        type: 'boolean',
        default:
          (Nn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Nn.defaults.show_count,
      },
      show_image: {
        type: 'boolean',
        default:
          (Pn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Pn.defaults.show_image,
      },
      show_description: {
        type: 'boolean',
        default:
          (Mn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Mn.defaults.show_description,
      },
      description_length: {
        type: 'number',
        default:
          (xn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : xn.defaults.description_length,
      },
      description_link: {
        type: 'boolean',
        default:
          (vn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : vn.defaults.description_link,
      },
      counter_brackets: {
        type: 'string',
        default:
          (kn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : kn.defaults.counter_brackets,
      },
      orderby: {
        type: 'string',
        default:
          (Rn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Rn.defaults.orderby,
      },
      order: {
        type: 'string',
        default:
          (Fn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Fn.defaults.order,
      },
      taxonomy: {
        type: 'array',
        default: $o(
          (Un =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Un.defaults.taxonomy,
        ),
      },
      post: {
        type: 'boolean',
        default:
          (zn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : zn.defaults.post,
      },
      parent_category: {
        type: 'string',
        default:
          (Hn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Hn.defaults.parent_category,
      },
      max_depth: {
        type: 'number',
        default:
          (Bn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Bn.defaults.max_depth,
      },
      exclude: {
        type: 'array',
        default:
          (Gn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Gn.defaults.exclude,
      },
      sortable: { type: 'string', default: '' },
      custom_class: {
        type: 'string',
        default:
          (Wn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Wn.defaults.custom_class,
      },
      block_custom_class: {
        type: 'string',
        default:
          (jn =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : jn.defaults.block_custom_class,
      },
    },
    edit({ attributes: o, setAttributes: n }) {
      var Ve, Ze, we, qe, Ne, y, Pe, b;
      let {
          list: s,
          layout: u,
          columns: m,
          lang: g,
          separator: D,
          hide_empty: ae,
          show_count: v,
          show_image: le,
          show_description: Ce,
          description_length: ge,
          description_link: Z,
          counter_brackets: at,
          orderby: Oe,
          order: Ue,
          taxonomy: q,
          post: H,
          parent_category: ze,
          max_depth: Ie,
          exclude: C,
          custom_class: z,
          block_custom_class: M,
        } = o,
        [W, He] = de(
          ((Ve =
            CategoriesAllInOnePluginData == null
              ? void 0
              : CategoriesAllInOnePluginData.dictionaries) == null
            ? void 0
            : Ve.taxonomies) || [],
        ),
        [Be, se] = de([]),
        [De, K] = de([]),
        [J, lt] = de([]),
        [ce, Le] = de([]),
        [Ge, We] = de(!1),
        [je, vt] = de(
          Object.values(
            (Ze =
              CategoriesAllInOnePluginData == null
                ? void 0
                : CategoriesAllInOnePluginData.dictionaries) == null
              ? void 0
              : Ze.languages,
          ) || [],
        );
      An(() => {
        let l = new AbortController(),
          p = 500,
          I = null;
        We(!0);
        let j = `?post_id=${CategoriesAllInOnePluginData.postId}`;
        return (
          (I = setTimeout(() => {
            fetch(window.CategoriesAllInOneRest.categoriesUrl(CategoriesAllInOnePluginData), {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': CategoriesAllInOnePluginData.nonce,
              },
              body: JSON.stringify(o),
              signal: l.signal,
            })
              .then((_) => {
                if (!_.ok) throw new Error('Failed to fetch categories');
                return _.json();
              })
              .then((_) => {
                (se(_ == null ? void 0 : _.categoriesForSelect),
                  K(_ == null ? void 0 : _.categoriesForExclude),
                  lt(_ == null ? void 0 : _.categoriesForSortable),
                  Le(_ == null ? void 0 : _.formattedHtmlData));
              })
              .catch((_) => {
                _.name !== 'AbortError' && console.error('API Error:', _);
              })
              .finally(() => {
                l.signal.aborted || We(!1);
              });
          }, p)),
          () => {
            (clearTimeout(I), l.abort());
          }
        );
      }, [o]);
      let A = (l) => {
          let p = o.taxonomy.includes(l) ? o.taxonomy.filter((I) => I !== l) : [...o.taxonomy, l];
          n({ taxonomy: p, post: '', parent_category: '', exclude: '', sortable: '' });
        },
        st = (l, p) => {
          let I = p ? [...C, l] : C.filter((j) => j !== l);
          n({ exclude: I, sortable: '' });
        },
        Ye = (l) =>
          l.map((p) => {
            var I;
            return r.createElement(
              'li',
              { key: p.term_id },
              r.createElement(re, {
                __nextHasNoMarginBottom: !0,
                label: p.name + ' (' + p.count + ')',
                checked: C.includes(p.term_id),
                onChange: (j) => st(p.term_id, j),
                style: { lineHeight: '2.1', display: 'inline-block' },
              }),
              ((I = p.children) == null ? void 0 : I.length) > 0
                ? r.createElement(
                    'ul',
                    { className: 'categories-all-in-one-exclude-item-children-container' },
                    Ye(p.children),
                  )
                : r.createElement('div', null),
            );
          }),
        $e = (l) =>
          l.map((p) => {
            var I;
            return r.createElement(
              'li',
              { key: p.term_id, 'data-term-id': p.term_id },
              r.createElement(
                'div',
                { className: 'categories-all-in-one-sortable-item' },
                r.createElement(Yo, null),
                ' ',
                p.name + ' (' + p.count + ')',
                ((I = p.children) == null ? void 0 : I.length) > 0 &&
                  r.createElement(
                    'ul',
                    { className: 'categories-all-in-one-sortable-item-children-container' },
                    $e(p.children),
                  ),
              ),
            );
          }),
        Xe = (l) => {
          setTimeout(() => {
            me('.categories-all-in-one-sortable-container').length > 0
              ? me(
                  '.categories-all-in-one-sortable-container, .categories-all-in-one-sortable-item-children-container',
                ).sortable({
                  opacity: 1,
                  placeholder: 'categories-all-in-one-sortable-item-placeholder',
                  update: function (p, I) {
                    let j = me('.categories-all-in-one-sortable-root'),
                      _ = Yn(j);
                    n({ sortable: btoa(JSON.stringify(_)) });
                  },
                })
              : Xe(l);
          }, 100);
        };
      return (
        An(
          () => (
            Xe(J),
            () => {
              me(
                '.categories-all-in-one-sortable-container, .categories-all-in-one-sortable-item-children-container',
              ).each(function () {
                me(this).hasClass('ui-sortable') && me(this).sortable('destroy');
              });
            }
          ),
          [J],
        ),
        r.createElement(
          'div',
          { style: { position: 'relative' } },
          r.createElement(
            Go,
            null,
            Ge &&
              r.createElement(
                r.Fragment,
                null,
                r.createElement('div', { className: 'active categories-all-in-one-block-loader' }),
                r.createElement('div', { className: 'active categories-all-in-one-block-spinner' }),
              ),
            r.createElement(
              En,
              { title: T('Query options', 'categories-all-in-one') },
              r.createElement(ie, {
                label: T('Language', 'categories-all-in-one'),
                value: g,
                options: je && je.map((l) => ({ value: l.language_code, label: l.native_name })),
                onChange: (l) => {
                  n({ lang: l, post: '', parent_category: '', exclude: '', sortable: '' });
                },
              }),
              r.createElement(re, {
                label: T('Only categories from this content', 'categories-all-in-one'),
                checked: H,
                onChange: (l) => {
                  var p;
                  return n({ post: l, parent_category: '', exclude: '', sortable: '' });
                },
              }),
              r.createElement(
                xt,
                { label: T('Category source', 'categories-all-in-one') },
                W &&
                  r.createElement(
                    'ul',
                    { className: 'categories-all-in-one-tree' },
                    W.map((l) =>
                      r.createElement(
                        'li',
                        { key: l.value },
                        r.createElement(re, {
                          name: 'taxonomy',
                          id: `taxonomy-${l.value}`,
                          label: l.label,
                          value: l.value,
                          disabled: H === !0,
                          checked: q && q.includes(l.value),
                          onChange: () => A(l.value),
                        }),
                      ),
                    ),
                  ),
              ),
              r.createElement(ie, {
                label: T('Categories from parent', 'categories-all-in-one'),
                value: ze.toString(),
                options: Be || [],
                disabled: H === !0,
                onChange: (l) => n({ parent_category: l.toString(), exclude: '', sortable: '' }),
              }),
              r.createElement(ie, {
                label: T('Order by', 'categories-all-in-one'),
                value: Oe,
                options:
                  ((we =
                    CategoriesAllInOnePluginData == null
                      ? void 0
                      : CategoriesAllInOnePluginData.dictionaries) == null
                    ? void 0
                    : we.ordersBy) || [],
                onChange: (l) => n({ orderby: l, exclude: '', sortable: '' }),
              }),
              r.createElement(ie, {
                label: T('Order', 'categories-all-in-one'),
                value: Ue,
                options:
                  ((qe =
                    CategoriesAllInOnePluginData == null
                      ? void 0
                      : CategoriesAllInOnePluginData.dictionaries) == null
                    ? void 0
                    : qe.orders) || [],
                onChange: (l) => n({ order: l, exclude: '', sortable: '' }),
              }),
              r.createElement(Fe, {
                label: T('Category hierarchy depth', 'categories-all-in-one'),
                value: parseInt(Ie),
                type: 'number',
                min: 0,
                onChange: (l) => n({ max_depth: parseInt(l), exclude: '', sortable: '' }),
                help: T('0 means no depth limit.', 'categories-all-in-one'),
              }),
              r.createElement(re, {
                label: T('Hide empty', 'categories-all-in-one'),
                checked: ae,
                onChange: (l) => n({ hide_empty: l, exclude: '', sortable: '' }),
              }),
              r.createElement(
                xt,
                { label: T('Exclude categories', 'categories-all-in-one') },
                r.createElement(
                  'div',
                  {
                    className: 'exclude',
                    style: { marginTop: '5px', display: 'inline-block', width: '100%' },
                  },
                  De.length
                    ? r.createElement(
                        'ul',
                        {
                          className:
                            'categories-all-in-one-exclude-container categories-all-in-one-exclude-root categories-all-in-one-tree',
                        },
                        Ye(De, C),
                      )
                    : T('No categories', 'categories-all-in-one'),
                ),
              ),
              Ue !== 'rand' &&
                r.createElement(
                  xt,
                  { label: T('Customize category order', 'categories-all-in-one') },
                  r.createElement(
                    'div',
                    {
                      className: 'categories-all-in-one-sortable',
                      style: { marginTop: '5px', display: 'inline-block', width: '100%' },
                    },
                    J != null && J.length
                      ? r.createElement(
                          'ul',
                          {
                            className:
                              'categories-all-in-one-sortable-container categories-all-in-one-sortable-root',
                          },
                          $e(J),
                        )
                      : T('No categories', 'categories-all-in-one'),
                  ),
                ),
              r.createElement(ie, {
                label: T('Layout', 'categories-all-in-one'),
                value: u,
                options:
                  ((Ne =
                    CategoriesAllInOnePluginData == null
                      ? void 0
                      : CategoriesAllInOnePluginData.dictionaries) == null
                    ? void 0
                    : Ne.layouts) || [],
                onChange: (l) => n({ layout: l }),
              }),
              u !== 'list' &&
                r.createElement(ie, {
                  label: T('Columns', 'categories-all-in-one'),
                  value: m,
                  options:
                    ((y =
                      CategoriesAllInOnePluginData == null
                        ? void 0
                        : CategoriesAllInOnePluginData.dictionaries) == null
                      ? void 0
                      : y.columns) || [],
                  onChange: (l) => n({ columns: parseInt(l, 10) }),
                }),
              u === 'list' &&
                r.createElement(ie, {
                  label: T('List type', 'categories-all-in-one'),
                  value: s,
                  options:
                    ((Pe =
                      CategoriesAllInOnePluginData == null
                        ? void 0
                        : CategoriesAllInOnePluginData.dictionaries) == null
                      ? void 0
                      : Pe.list) || [],
                  onChange: (l) => n({ list: l }),
                }),
              r.createElement(re, {
                label: T('Show count', 'categories-all-in-one'),
                checked: v,
                onChange: (l) => n({ show_count: l }),
              }),
              r.createElement(re, {
                label: T('Show category image', 'categories-all-in-one'),
                checked: le,
                onChange: (l) => n({ show_image: l }),
              }),
              r.createElement(ie, {
                label: T("Counter's brackets", 'categories-all-in-one'),
                value: at,
                options:
                  ((b =
                    CategoriesAllInOnePluginData == null
                      ? void 0
                      : CategoriesAllInOnePluginData.dictionaries) == null
                    ? void 0
                    : b.counterBrackets) || [],
                onChange: (l) => n({ counter_brackets: l }),
              }),
              r.createElement(re, {
                label: T('Show description', 'categories-all-in-one'),
                checked: Ce,
                onChange: (l) => n({ show_description: l }),
              }),
              r.createElement(Fe, {
                label: T('Description length in chars', 'categories-all-in-one'),
                value: parseInt(ge),
                type: 'number',
                min: 0,
                onChange: (l) => n({ description_length: parseInt(l) }),
                help: T('0 means no description limit.', 'categories-all-in-one'),
              }),
              r.createElement(re, {
                label: T('Description as link', 'categories-all-in-one'),
                checked: Z,
                onChange: (l) => n({ description_link: l }),
              }),
              r.createElement(Fe, {
                label: T('Separator for each category', 'categories-all-in-one'),
                value: D,
                onChange: (l) => n({ separator: l }),
              }),
              r.createElement(Fe, {
                label: T('Custom CSS class(es) for each category', 'categories-all-in-one'),
                value: z,
                onChange: (l) => n({ custom_class: l }),
                help: T('Separate multiple classes with spaces.', 'categories-all-in-one'),
              }),
            ),
            r.createElement(
              En,
              { title: T('Advanced', 'categories-all-in-one') },
              r.createElement(Fe, {
                label: T('Additional CSS class(es) for block', 'categories-all-in-one'),
                value: M,
                onChange: (l) => n({ block_custom_class: l }),
                help: T('Separate multiple classes with spaces.', 'categories-all-in-one'),
              }),
            ),
            r.createElement(
              Wo,
              { className: 'cci-categories-all-in-one-editor-brand' },
              r.createElement(
                jo,
                { size: 'xSmall' },
                r.createElement('img', {
                  src: CategoriesAllInOnePluginData.brandLogo,
                  width: '48',
                  height: '48',
                  alt: '',
                }),
                r.createElement(
                  'div',
                  null,
                  r.createElement(
                    'strong',
                    null,
                    CategoriesAllInOnePluginData.translations.brandTitle,
                  ),
                  r.createElement('p', null, CategoriesAllInOnePluginData.translations.brandText),
                  r.createElement(
                    'a',
                    {
                      href: CategoriesAllInOnePluginData.productUrl,
                      target: '_blank',
                      rel: 'noreferrer',
                    },
                    CategoriesAllInOnePluginData.translations.brandButton,
                  ),
                ),
              ),
            ),
          ),
          r.createElement(
            'div',
            null,
            ce
              ? r.createElement('div', {
                  className: 'categories-all-in-one-block-preview',
                  dangerouslySetInnerHTML: { __html: bn.sanitize(ce) },
                })
              : r.createElement(
                  'p',
                  null,
                  T('Configure your categories settings.', 'categories-all-in-one'),
                ),
          ),
        )
      );
    },
    save({ attributes: o }) {
      return ((s) => {
        let u = '[categories_all_in_one';
        for (let m in s)
          if (s.hasOwnProperty(m)) {
            let g = s[m];
            (g == null && (g = ''),
              Array.isArray(g) && (g = g.join(',')),
              typeof g == 'boolean' && (g = g ? 'true' : 'false'),
              (u += ` ${m}="${g}"`));
          }
        return ((u += ']'), u);
      })(o);
    },
  });
})();
/*! Bundled license information:

dompurify/dist/purify.es.mjs:
  (*! @license DOMPurify 3.4.12 | (c) Cure53 and other contributors | Released under the Apache license 2.0 and Mozilla Public License 2.0 | github.com/cure53/DOMPurify/blob/3.4.12/LICENSE *)
*/
